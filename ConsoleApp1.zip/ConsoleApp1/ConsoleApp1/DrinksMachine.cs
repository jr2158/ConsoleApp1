﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;



namespace ConsoleApp1
{
    class DrinksMachine
    {
        //The following statements declare private member variables
        private string _location;
        private string _make;
        private string _model;

        public string Location { get => _location; set => _location = value; }
        public string Model { get => _model; set => _model = value; }
        public string Make { get => _make; set => _make = value; }

        public DrinksMachine(string _location, string _model)
        {
            this.Location = _location;
            this.Model = _model;
        }

        //The following statements declare public methods
        public void MakeCappuccino()
        {
            Console.WriteLine(this.Location + " " + this.Make);
        }

        public void MakeExpresso()
        {
            
        }
    }








    //CREATING AND INHERITING FROM ABSTRACT CLASS
    abstract class Employee
    {
        private string empNumber;
        private string firstName;
        private string lastName;
        private string address;

        public string EmpNumber { get => empNumber; set => empNumber = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string Address { get => address; set => address = value; }

        public virtual void Login()
        {
            Console.WriteLine("Employee login");
        }

        public abstract void Hire();
    }




    class Manager : Employee
    {
        private string department;

        public string Department { get => department; set => department = value; }

        public override void Login()
        {
            //base.Login();
            Console.WriteLine("Manager Login");
        }

        public override void Hire()
        {
            //throw new NotImplementedException();
            Console.WriteLine("Hire someone");
        }
    }













    //CREATING AND WORKING WITH INTERFACES
    interface ILoyaltyCardHolder
    {
        int TotalPoints { get; }
        int AddPoints(decimal transactionValue);
        void ResetPoints();
    }


    class Customer : ILoyaltyCardHolder
    {
        private int totalPoints;

        public int TotalPoints
        {
            get { return totalPoints; }
        }

        public int AddPoints(decimal transactionValue)
        {
            int points = Decimal.ToInt32(transactionValue);
            totalPoints += points;
            return totalPoints;
        }

        public void ResetPoints()
        {
            totalPoints = 0;
        }
    } 
}
