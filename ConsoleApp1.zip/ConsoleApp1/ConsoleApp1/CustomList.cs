﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class CustomList<T>
    {
        //public T this[int index] { get; set; }

        public void Add(T item)
        {
            //Method logic goies here.
        }

        public void Remove(T item)
        {
            //Method logic goes here.
        }
    }


    #region GenericCollection
    
    #endregion
}
