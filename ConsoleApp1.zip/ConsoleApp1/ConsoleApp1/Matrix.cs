﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Matrix
    {
        string welcome;

        public Matrix(string welcome)
        {
            this.welcome = welcome;
        }



        public int[][] MatrixMulti(int [][] a, int[][] b)
        {
            int[][] c = new int[a.Length][];

            for (int size = 0; size < c.Length; size++)
                c[size] = new int[b[0].Length];

            for(int i = 0; i < c.Length; i++)
            {
                for(int j = 0; j < c[0].Length; j++)
                {
                    c[i][j] = a[i][j] + b[i][j];
                }
            }

            return c;
        }
    }
}
