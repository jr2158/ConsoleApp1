﻿using System;
using System.Collections.Generic;
using System.Text;






namespace ConsoleApp1
{
    class Palindrome
    {
        public static bool IsPalindrome(string pal)
        {
            if(pal.Length == 1)
            {
                return true;
            }
            else
            {
                if(pal[0] == pal[pal.Length-1])
                {
                    return IsPalindrome(pal.Substring(1, pal.Length - 2));
                }
                else
                {
                    return false;
                }
            }
        }
    }
}
