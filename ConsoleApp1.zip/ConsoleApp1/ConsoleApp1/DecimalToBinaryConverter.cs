﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class DecimalToBinaryConverter
    {
        public static string DecToBin(int n)
        {
            if (n == 0 || n == 1)
                return n.ToString();
            return DecToBin(n / 2) + (n % 2).ToString();
        }


        public static int Gcd(int x, int y)
        {
            if (y == 0)
                return x;
            return Gcd(y, x % y);
        }
    }
}
