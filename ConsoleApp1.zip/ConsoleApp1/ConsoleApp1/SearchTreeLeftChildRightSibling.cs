﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class SearchTreeLeftChildRightSibling
    {
        public class Node
        {
            int key;
            Node parent, leftChild, rightSibling;

            public Node(int key, Node parent, Node leftChild, Node rightSibling)
            {
                this.key = key;
                this.parent = parent;
                this.leftChild = leftChild;
                this.rightSibling = rightSibling;
            }
        }

        Node root;

        public void Insert(int key)
        {
        
        }

        public void Delete(int key)
        {

        }

        public Node Search(int key)
        {
            return null;
        }
    }
}