﻿using System;

namespace ConsoleApp1
{
    public class Bst
    {
        public class Node
        {
            public int key;
            public Node leftChild, rightChild, parent;

            public Node(int key, Node leftChild, Node rightChild, Node parent)
            {
                this.key = key;
                this.leftChild = leftChild;
                this.rightChild = rightChild;
                this.parent = parent;
            }
        }


        Node root;
        int minNodeKey;

        public void Insert(int key)
        {
            root = Insert(root, key);
        }


        private Node Insert(Node node, int key)
        {
            if (node == null)
            {
                node = new Node(key, null, null, null);
                return node;
            }
            else if(node.key > key)
            {
                node.leftChild = Insert(node.leftChild, key);
                return node;
            }
            else
            {
                node.rightChild = Insert(node.rightChild, key);
                return node;
            }
        }



        public void Delete(int key)
        {
            root = Delete(root, key);
        }

        private Node Delete(Node node, int key)
        {
           if(node == null)
            {
                return null;
            }
           else if(node.key == key)
            {
                if(node.leftChild != null && node.rightChild != null)
                {
                    DeleteMin(node.rightChild);
                    node.key = minNodeKey;
                    return node;
                }
                else if(node.leftChild != null && node.rightChild == null)
                {
                    node = node.leftChild;
                    return node;
                }
                else if(node.leftChild == null && node.rightChild != null)
                {
                    node = node.rightChild;
                    return node;
                }
                else
                {
                    node = null;
                    return node;
                }
            }
           else if(node.key > key)
            {
                node.leftChild = Delete(node.leftChild, key);
                return node;
            }
           else if(node.key < key)
            {
                node.rightChild = Delete(node.rightChild, key);
                return node;
            }
            return null;
        }

        private void DeleteMin(Node node)
        {
            if(node.leftChild == null)
            {
                minNodeKey = node.key;
                if(node.rightChild != null)
                {
                    node = node.rightChild;
                }
            }
            else
            {
                DeleteMin(node.leftChild);
            }
        }

        public Node Search(int key)
        {
            return Search(root, key);
        }

        private Node Search(Node node, int key)
        {
            if(node == null)
            {
                return null;
            }
            else if(node.key == key)
            {
                return node;
            }
            else if(node.key > key)
            {
                return Search(node.leftChild, key);
            }
            else
            {
                return Search(node.rightChild, key);
            }
        }

        /*
        public static void Main(string[] args)
        {
            Bst bst = new Bst();
            bst.Insert(8);
            bst.Insert(4);
            bst.Insert(6);
            bst.Insert(2);
            Node result = bst.Search(2);
            string str = result == null ? "Not found!" : "Found!";
            Console.WriteLine(str);
        }
        */
    }
}