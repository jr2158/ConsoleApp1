﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.IO;


namespace ConsoleApp1
{
    class Program
    {
        //APIE abstraction, polymorphism, inheritance, encapsulation
        //struct, enum
        //Classes - partial, static, anonymous, abstract, sealed, interface
        //class inheritance

        public static void Main(string[] args)
        {
            //string result = DecimalToBinaryConverter.DecToBin(15);
            //Console.WriteLine("'b{0}'", result)

            /*
            Matrix matrix = new Matrix("Welcome matrix multiplication algo!!");

            int[][] a = { { 1, 2 }, { 3, 4 } };
            int[][] b = { { 2, 0 }, { 1, 2 } };
            int[][] res = matrix.MatrixMulti(a, b);


            for(int i = 0; i < res.Length; i++)
            {
                for(int j = 0; j < res[0].Length; j++)
                {
                    Console.WriteLine(res[i][j] + " ");
                }
                Console.WriteLine("\n");
            }
            
            
            
            string pal = Console.ReadLine();
            while(pal != "stop")
            {
                Console.WriteLine(Palindrome.IsPalindrome(pal));
                pal = Console.ReadLine();
            }
            
            Console.WriteLine("Please insert X value...");
            int x = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Please insert Y value...");
            int y = Int32.Parse(Console.ReadLine());

            Console.WriteLine("gcd({0}, {1}) = {2}", x, y, DecimalToBinaryConverter.Gcd(x, y));
            */

            ArrayList alist = new ArrayList();

            alist.Add("dn: cn=John Doe,dc=example,dc=com\n" +
                      "cn: John Doe\n" +
                      "givenName: John\n" +
                      "sn: Doe\n" +
                      "telephoneNumber: +1 888 555 6789\n" +
                      "telephoneNumber: +1 888 555 1232\n" +
                      "mail: john@example.com\n" +
                      "manager: cn=Barbara Doe,dc=example,dc=com\n" +
                      "objectClass: inetOrgPerson\n" +
                      "objectClass: organizationalPerson\n" +
                      "objectClass: person\n" +
                      "objectClass: top\n");
            alist.Add("dn: cn=Alice Smith,dc=example,dc=com\n" +
                      "cn: Alice Smith\n" +
                      "givenName: Alice\n" +
                      "sn: Smith\n" +
                      "telephoneNumber: +1 223 532 2355\n" +
                      "telephoneNumber: +1 452 232 7790\n" +
                      "mail: alice@example.com\n" +
                      "manager: cn=Barbara Doe,dc=example,dc=com\n" +
                      "objectClass: inetOrgPerson\n" +
                      "objectClass: organizationalPerson\n" +
                      "objectClass: person\n" +
                      "objectClass: top\n");

            Console.WriteLine("------------------  These are the entries in the LDAP server  -------------------------\n");
            foreach(string record in alist)
            {
                Console.WriteLine(record);
            }

            //
        }
    }

}